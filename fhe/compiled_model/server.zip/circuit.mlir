module {
  func.func @inference_to_compile(%arg0: tensor<1x6x!FHE.esint<15>>) -> tensor<1x3x!FHE.esint<15>> {
    %cst = arith.constant dense<[[-32, 1, 31], [-25, 1, 25], [-19, 0, 18], [-19, 0, 19], [-13, 1, 12], [-19, 1, 18]]> : tensor<6x3xi7>
    %0 = "FHELinalg.matmul_eint_int"(%arg0, %cst) : (tensor<1x6x!FHE.esint<15>>, tensor<6x3xi7>) -> tensor<1x3x!FHE.esint<15>>
    %1 = "FHELinalg.sum"(%arg0) {axes = [1], keep_dims = true} : (tensor<1x6x!FHE.esint<15>>) -> tensor<1x1x!FHE.esint<15>>
    %c0_i2 = arith.constant 0 : i2
    %from_elements = tensor.from_elements %c0_i2 : tensor<1xi2>
    %2 = "FHELinalg.to_unsigned"(%1) : (tensor<1x1x!FHE.esint<15>>) -> tensor<1x1x!FHE.eint<15>>
    %3 = "FHELinalg.mul_eint_int"(%2, %from_elements) : (tensor<1x1x!FHE.eint<15>>, tensor<1xi2>) -> tensor<1x1x!FHE.eint<15>>
    %4 = "FHELinalg.to_signed"(%3) : (tensor<1x1x!FHE.eint<15>>) -> tensor<1x1x!FHE.esint<15>>
    %5 = "FHELinalg.sub_eint"(%0, %4) : (tensor<1x3x!FHE.esint<15>>, tensor<1x1x!FHE.esint<15>>) -> tensor<1x3x!FHE.esint<15>>
    %cst_0 = arith.constant dense<[[7799, 373, -8172]]> : tensor<1x3xi15>
    %6 = "FHELinalg.add_eint_int"(%5, %cst_0) : (tensor<1x3x!FHE.esint<15>>, tensor<1x3xi15>) -> tensor<1x3x!FHE.esint<15>>
    return %6 : tensor<1x3x!FHE.esint<15>>
  }
}